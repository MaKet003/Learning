// Copyright (c) Microsoft Corporation. All Rights Reserved.
// Licensed under the MIT License.

using Xamarin.Forms.Xaml;

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]