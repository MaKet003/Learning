﻿// Copyright (c) Microsoft Corporation. All Rights Reserved.
// Licensed under the MIT License.

namespace ThreadedPushTest
{
    internal class Constants
    {
        public static string Endpoint
        {
            get => "https://tpt.azurewebsites.net";
        }
    }
}
